from setuptools import setup

setup(
    name='PyMMAX2',
    packages=['pymmax2'],
    include_package_data=True,
    version="0.65.2"
    )